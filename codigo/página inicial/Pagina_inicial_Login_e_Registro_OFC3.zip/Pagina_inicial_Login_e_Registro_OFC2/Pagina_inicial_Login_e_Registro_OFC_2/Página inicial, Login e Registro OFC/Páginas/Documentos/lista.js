var cadastro = [{ "nome": "Pedro", "cidade": "BH", "idade": 25, "veiculos": [{ "marca": "Fiat", "modelo": "Toro", "ano": "2020", "placa": "SESE" }] }, { "nome": "Anna", "cidade": "BH", "idade": 40, "veiculos": [] }, { "nome": "Gustavo", "cidade": "BH", "idade": 45, "veiculos": [{ "marca": "Ford", "modelo": "Sese", "ano": 2001 }, { "marca": "Fiat", "modelo": "Sese", "ano": 2003 }] }];

function ExibirCadastro(){
    var textHTML = '';
    for (let x = 0; x < cadastro.length; x++){
        textHTML += `Pessoa: ${cadastro[x].nome} <br>`;

        if (cadastro[x].veiculos.length > 0){
            textHTML += '<ul>';
        }

        for (let y = 0; y < cadastro[x].veiculos.length; y++){
            let marca = cadastro[x].veiculos[y].marca;
            let modelo = cadastro[x].veiculos[y].modelo;
            let ano = cadastro[x].veiculos[y].ano;
            let placa = cadastro[x].veiculos[y].placa;
            textHTML += `<li>${marca} - ${modelo} - ${placa} - ${ano}</li>`
        }

        if (cadastro[x].veiculos.length > 0){
            textHTML += '</ul>';
        }
    }

    //alert(textHTML);
    var tela = document.getElementById('tela');
    tela.innerHTML = textHTML;
}