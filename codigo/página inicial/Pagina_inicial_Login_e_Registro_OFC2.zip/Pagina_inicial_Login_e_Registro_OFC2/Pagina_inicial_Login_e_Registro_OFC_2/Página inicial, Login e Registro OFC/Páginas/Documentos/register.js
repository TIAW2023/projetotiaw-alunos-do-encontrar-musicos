function view() {
  let inputSen = document.querySelector('#sen');

  if (inputSen.getAttribute('type') == 'password') {
      inputSen.setAttribute('type', 'text');
  }
  else {
      inputSen.setAttribute('type', 'password');
  }
}

let objDados = [
    { nome: "Pedro", email: "pedro@hotmail.com", senha: "0503nitro" },
    { nome: "Anna", email: "anna@hotmail.com", senha: "0503nitro" },
    { nome: "Luis", email: "luis@hotmail.com", senha: "0503nitro" }];


  //inserir
    localStorage.setItem("cont", JSON.stringify(objDados));

  //resgatar
  let dados = localStorage.getItem("cont");

  //atualizar
  function salvaDados(newDados) {
    localStorage.setItem("cont", JSON.stringify(newDados));
  }

  function incluirContato() {

    //Incluir um novo contato
    let strNome = document.querySelector('#nom').value;
    let strEmail = document.querySelector('#ema').value;
    let strSenha = document.querySelector('#sen').value;
    let novoUsuario = {
      nome: strNome,
      email: strEmail,
      senha: strSenha,
      bio: null,
      instrumento: null
    };
    objDados.push(novoUsuario);
    localStorage.setItem("cont", JSON.stringify(objDados));
    //Salvar os dados no localStorage novamente
    salvaDados(objDados);

    imprimeDados();
  }


  function imprimeDados() {
    let tela = document.getElementById("tela");
    let strHtml = '';

    for (let i = 0; i < objDados.length; i++) {
      strHtml += `<p>${objDados[i].nome} - ${objDados[i].email} - ${objDados[i].senha}</p>`
    }

    tela.innerHTML = strHtml;
  }