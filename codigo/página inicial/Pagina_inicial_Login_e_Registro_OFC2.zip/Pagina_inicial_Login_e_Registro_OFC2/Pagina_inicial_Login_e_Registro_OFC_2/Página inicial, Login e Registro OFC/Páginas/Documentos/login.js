function view() {
    let inputSen = document.querySelector('#sen');

    if (inputSen.getAttribute('type') == 'password') {
        inputSen.setAttribute('type', 'text');
    }
    else {
        inputSen.setAttribute('type', 'password');
    }
}

function veri() {
    let strEmail = document.querySelector('#em2').value;
    let strSenha = document.querySelector('#sen2').value;
    let cont = {};
    cont = JSON.parse(localStorage.getItem('cont'));
    let tela = document.getElementById("tela");
    for (let i = 0; i < cont.length; i++) {
        if (strEmail == cont[i].email && strSenha == cont[i].senha) {
            tela.innerHTML = `<p id = "acess">Acesso permitido</p>`
        }
        else{
            tela.innerHTML = `<p id = "acess">Acesso negado, <br> revise sua senha e/ou endereço de email</p>`
        }
    }
}