
//LÊ os dados do banco verificando se o Banco de dados "db" (resumido na váriavel "strDados") estiver vazia, colocar os dados de objeto (json) feitos como "usuarios"
function leDados() {
    let strDados = localStorage.getItem('db');
    let objDados = {};

    if (strDados) {
        objDados = JSON.parse(strDados);
    }
    else {
        objDados = {
            contatos: [
                { nome: "Pedro", email: "pedro@hotmail.com", senha: "0503nitro" },
                { nome: "Anna", email: "anna@hotmail.com", senha: "0503nitro" },
                { nome: "Luis", email: "luis@hotmail.com", senha: "0503nitro" }
            ]
        }
    }

    return objDados;
}


//Transforma as informações objetidas em JSON e as passa como string para o Banco de Dados (ele só aceita string), assim salvando a string no db
function salvaDados(dados) {
    localStorage.setItem('db', JSON.stringify(dados));
}

function incluirContato() {
    //Ler os dados do localStorage
    let objDados = leDados();

    //Incluir um novo contato
    let strNome = document.getElementById('nom').value;
    let strEmail = document.getElementById('ema').value;
    let strSenha = document.getElementById('sen').value;
    let novoUsuario = {
        nome: strNome,
        email: strEmail,
        senha: strSenha
    };
    objDados.usuarios.push(novoUsuario);

    //Salvar os dados no localStorage novamente
    salvaDados(objDados);

    imprimeDados();
}

//Escreve os dados definidos em um espaço definido pela let teste

function imprimeDados() {
    let tela = document.getElementById('tela');
    let strHtml = '';
    let objDados = leDados();

    for (i = 0; i < objDados.contatos.lenght; i++) {
        strHtml += `<p>${objDados.contatos[i].nome} - ${objDados.contatos[i].email} - ${objDados.contatos[i].senha}</p>`
    }

    tela.innerHTML = strHtml;
}

localStorage.removeItem("a");
// Trocar esse strHtml pelo strDados